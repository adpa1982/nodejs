const { Router } = require('express');
// const { check } = require('express-validator');

const { usuariosGet,
        usuariosPost,
        usuariosPut,
        usuariosDelete,
        usuariosPatch } = require('../controllers/usuarios');
const { createRulesUsuario,
        updateRulesUsuario,
        deleteRulesUsuario } = require('../controllers/request/rules-usuario');
const { validarCampos } = require('../middlewares/validar-campo');

const router = Router();

router.get('/', usuariosGet);

router.post('/',[
    createRulesUsuario(),
    validarCampos
], usuariosPost);

router.put('/:id', [
    updateRulesUsuario(),
    validarCampos
], usuariosPut);

router.delete('/:id', [
    deleteRulesUsuario(),
    validarCampos
], usuariosDelete);

router.patch('/', usuariosPatch);

module.exports = router;